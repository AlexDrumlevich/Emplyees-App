package telran.employees.dto;

import java.io.Serializable;

public record FromTo(int from, int to) implements Serializable{

}