package telran.net;

public enum ResponseCode {
OK, WRONG_TYPE, WRONG_DATA
}
