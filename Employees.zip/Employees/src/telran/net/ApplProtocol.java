package telran.net;

public interface ApplProtocol {
Response getResponse(Request request);
}
